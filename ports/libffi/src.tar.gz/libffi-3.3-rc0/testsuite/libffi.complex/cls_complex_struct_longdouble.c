/* Area:	ffi_call, closure_call
   Purpose:	Check complex arguments in structs.
   Limitations:	none.
   PR:		none.
   Originator:	<vogt@linux.vnet.ibm.com>.  */

/* { dg-do run } */

#include "complex_defs_longdouble.inc"
#include "cls_complex_struct.inc"
