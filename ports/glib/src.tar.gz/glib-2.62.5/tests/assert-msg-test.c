#include <glib.h>

int main(int argc, char **argv)
{
    g_assert(42 < 0);
    return 0;
}

